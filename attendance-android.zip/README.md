# Attendance App – build the Android APK on GitHub

1. github.com -> **New repository** (name: attendance-app) -> Create.
2. **Add file -> Upload files**. Drag ALL files and folders from this project
   (www, .github, package.json, capacitor.config.json, .gitignore) -> **Commit changes**.
3. Open the **Actions** tab. "Build APK" starts by itself (about 6-10 minutes).
   If it does not: Actions -> Build APK -> **Run workflow**.
4. When the run shows a green tick, open it -> **Artifacts** -> download **attendance-apk**.
5. Unzip it. Copy **app-debug.apk** to the phone, tap it, allow "Install unknown apps".

To change the app later, edit www/index.html on GitHub and commit. A new APK is built.
